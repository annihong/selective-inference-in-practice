library(testthat)
library(tmax)

test_check("tmax")
