context("PoSI-K")
library(pracma)
library(matrixStats)

library(tmax)
source("../../R/utilities.R")
# This file contains the functions Generate()
# and fixedx_posi().

# Sample setup
opt <- NULL
opt$xmat <- "a"				# sample setup
opt$nrow <- 200				# sample size
opt$ncol <- 5			    # number of covariates
opt$maxk <- 5					# max model size
opt$seed_beta <- 123	# random seed for X, beta
opt$seed_eps <- 100		# random seed for error
opt$conf_level <- .95	# confidence level
opt$nboot <- 1000			# bootstrap sample size


# xmat = a ----------------------------------------------------------------

opt$xmat <- "a"	

# Generate sample
data <- Generate(opt)
xx <- data$x
yy <- data$y

# K
K <- maxt_posi(xx, yy, maxk = opt$maxk, sandwich = TRUE, alpha = 1-opt$conf_level, Nboot = opt$nboot)$k

test_that(sprintf("X: xmat%s_n%s_p%s_k%s_nboot%s", opt$xmat, opt$nrow, opt$ncol, opt$maxk, opt$nboot), {
  expect_equal(K, K)
})


# xmat = b ----------------------------------------------------------------

opt$xmat = "b"

# Generate sample
data <- Generate(opt)
xx <- data$x
yy <- data$y

# K
K <- maxt_posi(xx, yy, maxk = opt$maxk, sandwich = TRUE, alpha = 1-opt$conf_level, Nboot = opt$nboot)$k

test_that(sprintf("X: xmat%s_n%s_p%s_k%s_nboot%s", opt$xmat, opt$nrow, opt$ncol, opt$maxk, opt$nboot), {
  expect_equal(K, K)
})


# xmat = c and p = 10 ------------------------------------------------------------------

opt$ncol = 10
opt$xmat = "c"

# Generate sample
data <- Generate(opt)
xx <- data$x
yy <- data$y

# K
K <- maxt_posi(xx, yy, maxk = opt$maxk, sandwich = TRUE, alpha = 1-opt$conf_level, Nboot = opt$nboot)$k

test_that(sprintf("X: xmat%s_n%s_p%s_k%s_nboot%s", opt$xmat, opt$nrow, opt$ncol, opt$maxk, opt$nboot), {
  expect_equal(K, K)
})
